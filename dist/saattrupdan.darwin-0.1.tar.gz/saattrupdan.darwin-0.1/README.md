# Darwin

An all-purpose pythonic genetic algorithm.
