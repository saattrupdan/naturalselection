# naturalselection

An all-purpose pythonic genetic algorithm.
